/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.recibo;

/**
 *
 * @author Carlos M
 */
import javax.swing.JOptionPane;
        
public class Prueba {
    
    public int fechaped= 24;
    public int plantel= 2;
    public int sumlit= 20;
    public String destino= "Grecia";
    public int sumprecio= 20000;
    public int desc= 2000;
    public String firma;
    public String rifa[];
    
    public void factelect(){
        
        int op= Integer.parseInt(JOptionPane.showInputDialog(null, "Si desea su factura impresa, digite 1. Y si desea que se enviada por email, digite 2.", "PetroExpress", JOptionPane.QUESTION_MESSAGE));
        if (op==1){
            
        System.out.println("Fecha de pedido: "+fechaped);
        System.out.println("--------------------------");
        System.out.println("Nombre del plantel: "+plantel);
        System.out.println("----------------------------");
        System.out.println("Cantidad de litros solicitados: "+sumlit);
        System.out.println("---------------------------------------");
        System.out.println("Destino de entrega: "+destino);
        System.out.println("----------------------------");
        System.out.println("Su precio total en colones es: "+sumprecio+" con descuento de: "+desc);
        System.out.println("--------------------------------------------------------------------");
        firma= JOptionPane.showInputDialog(null, "Ingrese su firma", "Atención",JOptionPane.INFORMATION_MESSAGE);
        System.out.println("Firmado por: "+firma);
        System.out.println("-------------------");
        System.out.println("Transacción finalizada, gracias por preferirnos");
        System.out.println("-----------------------------------------------");
        }//fin del condicional
        else{
        String mail= JOptionPane.showInputDialog(null, "Ingrese su dirección de correo electrónico");
        JOptionPane.showMessageDialog(null, "La factura electrónica ha sido enviada a "+mail);
        }//fin del else
        
        
    }//fin del metodo factelect
    
    public void Rifa(){
        
        rifa= new String[11];
        
        int resp= Integer.parseInt(JOptionPane.showInputDialog(null, "Si desea participar en nuestra rifa, digite 1. De lo contrario, digite 2","PetroExpress",JOptionPane.QUESTION_MESSAGE));
        if(resp==1){ 
            
        int num= Integer.parseInt(JOptionPane.showInputDialog(null, "Ingresar un número del 1 al 10", "Rifa", JOptionPane.INFORMATION_MESSAGE));
            
        switch(num){
               
        case 1:
        rifa[1]= "Tanque lleno por un año";        
        
        
        case 2:
        rifa[2]= "Transporte gratis durante 3 meses";        
        
        
        case 3:
        rifa[3]= "30% de descuento";        
        
        
        case 4:
        rifa[4]= "10 galones gratis de gasolina super";    
        
        
        case 5:
        rifa[5]= "10 galones de gasolina plus91";   
        
        
        case 6:
        rifa[6]= "10 galones de gasolina diesel";        
        
        
        case 7:
        rifa[7]= "Camion Westernstar 4900 año 2020";    
        
        
        case 8:
        rifa[8]= "Camion Mercedes-Benz Actros año 2020";
        
        
        case 9:
        rifa[9]= "Camion SCANIA S-Sleeper año 2020";        
        
        
        case 10:
        rifa[10]= "Membresia Premium durante 1 año";
        
        }//fin del switch
            
        JOptionPane.showMessageDialog(null, "Felicidades, su premio es el siguiente: "+rifa[num], "PetroExpress", JOptionPane.INFORMATION_MESSAGE);
        
        }//fin del if
        else{
            JOptionPane.showMessageDialog(null, "¡Gracias por su compra!", "PetroExpress",JOptionPane.INFORMATION_MESSAGE);
            
        }//fin del else 
        
    }//fin del metodo Rifa
    
}//fin de la clase Prueba
