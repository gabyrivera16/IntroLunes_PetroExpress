/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.recibo;

/**
 *
 * @author Carlos M
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
       Prueba method= new Prueba();
       method.factelect();
       method.Rifa();
        
    
    
    }//fin del metodo main
    
}//fin de la clase Main
