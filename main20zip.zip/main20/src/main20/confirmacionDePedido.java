/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main20;

import javax.swing.JOptionPane;

/**
 *
 * @author PC
 */
public class confirmacionDePedido {
public void consultar(){    
    String mensaje="Digite 1 para confirmar pedido o digite 2 para cancelar pedido";
    int respuesta=Integer.parseInt(JOptionPane.showInputDialog(mensaje));
 if(respuesta==1){
    JOptionPane.showMessageDialog(null, "su pedido ha sido confirmado");
 }
 else{
     JOptionPane.showMessageDialog(null, " su pedido ha sido cancelado");
 }
}

}



