/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package petroexpress.petroexpress;
import javax.swing.JOptionPane;
/**
 *
 * @author 17adr
 */

public class ConsultasReportes {
    
       private String consult[];
        private String report [];
    
    
    public void Consultas() {
        
       consult= new String[6];
       
       JOptionPane.showMessageDialog(null, "Bienvenid@ al modulo de Consultas.");
    
        int showConfirmDialog = JOptionPane.showConfirmDialog(null, "Desea realizar una consulta?");
        
        if (showConfirmDialog == JOptionPane.YES_OPTION) {
            
            int num = Integer.parseInt(JOptionPane.showInputDialog(null, "Ingrese un número del 1 al 5 para realizar su consulta", "Consulta",JOptionPane.INFORMATION_MESSAGE));
            
            switch(num){
                
                case 1:
                consult[1]= JOptionPane.showInputDialog(null, null, "Consulta", JOptionPane.INFORMATION_MESSAGE);
                break;
                
                case 2:
                consult[2]=JOptionPane.showInputDialog(null, null, "Consulta", JOptionPane.INFORMATION_MESSAGE);
                break;
                
                case 3:
                consult[3]=JOptionPane.showInputDialog(null, null, "Consulta", JOptionPane.INFORMATION_MESSAGE);
                break;
                
                case 4:
                consult[4]=JOptionPane.showInputDialog(null, null, "Consulta", JOptionPane.INFORMATION_MESSAGE);
                break;
                
                case 5:
                consult[5]=JOptionPane.showInputDialog(null, null, "Consulta", JOptionPane.INFORMATION_MESSAGE);
                break;
            
            }//fin del switch
            
            JOptionPane.showMessageDialog(null, "La consulta "+consult[num]+" ha sido enviada. Le agradecemos su tiempo, en 24 hrs lo estaremos contactando.");
            
        }//fin del if
        
        if (showConfirmDialog == JOptionPane.NO_OPTION) {
            JOptionPane.showMessageDialog(null, "La Consulta no ha sido Enviada");
        }
        
        if (showConfirmDialog == JOptionPane.CANCEL_OPTION) {
            JOptionPane.showMessageDialog(null, "La Consulta ha sido Cancelada no se guardara en el registro");
        
        }
        
        
    }//final de consultas
    
    public void Reportes() {
        
        report= new String[6];
        
        JOptionPane.showMessageDialog(null, "Bienvenid@ al modulo de Reportes.");
        
        int showConfirmDialog = JOptionPane.showConfirmDialog(null, "Desea realizar un Reporte?");

        if (showConfirmDialog == JOptionPane.YES_OPTION) {
            
                int num2 = Integer.parseInt(JOptionPane.showInputDialog(null, "Ingrese un número del 1 al 5 para realizar su reporte", "Reporte",JOptionPane.INFORMATION_MESSAGE));
            
            switch(num2){
                
                case 1:
                report[1]= JOptionPane.showInputDialog(null, null, "Reporte", JOptionPane.INFORMATION_MESSAGE);
                break;
                
                case 2:
                report[2]=JOptionPane.showInputDialog(null, null, "Reporte", JOptionPane.INFORMATION_MESSAGE);
                break;
                
                case 3:
                report[3]=JOptionPane.showInputDialog(null, null, "Reporte", JOptionPane.INFORMATION_MESSAGE);
                break;
                
                case 4:
                report[4]=JOptionPane.showInputDialog(null, null, "Reporte", JOptionPane.INFORMATION_MESSAGE);
                break;
                
                case 5:
                report[5]=JOptionPane.showInputDialog(null, null, "Reporte", JOptionPane.INFORMATION_MESSAGE);
                break;
            
            }//fin del switch
            
            JOptionPane.showMessageDialog(null, "El reporte "+report[num2]+" ha sido enviado exitosamente."+"Lamentamos mucho el malentendido, estaremos en contacto con usted, y tomaremos las medidad necesarias lo antes posible.");
        }

        if (showConfirmDialog == JOptionPane.NO_OPTION) {
            JOptionPane.showMessageDialog(null, "El Reporte no ha sido Enviado");
        }

        if (showConfirmDialog == JOptionPane.CANCEL_OPTION) {
            JOptionPane.showMessageDialog(null, "El Reporte ha sido Cancelado.");
        }
      
    }//final de reportes
    
    
 
}//final de consultasreportes
