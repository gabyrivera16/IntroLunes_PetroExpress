/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package petroexpress.petroexpress;
import javax.swing.JOptionPane;
      
       
/**
 *
 * @author 17adr
 */

//Hecho por:
//Inicio/Registro, TransporteGasolina: Adriana Arrieta
//Recarga Electronica: Christian Salazar
//Confirmacion de pedido: Jubal Hackett
//Metodo de Pago: Nancy Echandi
//Consultas y Reportes: Jose Solano
//Rifa/Recibo: Carlos Espinoza

public class PetroExpress {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

      InicioRegistro registro = new InicioRegistro();
      registro.Bienvenida();
      registro.Registro();

      TransporteGasolina gasolina = new TransporteGasolina();
      gasolina.Bienvenida();
      gasolina.IngresoDatos();
      gasolina.MenuGasolina();
      
      RecargaElectrica recEl = new RecargaElectrica();
      recEl.Bienvenida();
      recEl.Menu();
     
      MetodoPago pago = new MetodoPago();
      pago.Bienvendida();
      pago.Descuentos();
      
      ConfirmacionPedido confiPed = new ConfirmacionPedido();
      confiPed.Bienvenida();
      confiPed.Consultar();
    
      Rifa rifa = new Rifa();
      rifa.rifaOpciones();
          
     ConsultasReportes consRep = new ConsultasReportes();
      consRep.Consultas();
      consRep.Reportes();
      
      Recibo rB = new Recibo();
      rB.factelect();
      
      JOptionPane.showMessageDialog(null, "Gracias por preferirnos", "PetroExpress", JOptionPane.INFORMATION_MESSAGE);

    }//final de main
    
}//final de clase
