/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package petroexpress.petroexpress;

import javax.swing.JOptionPane;

/**
 *
 * @author 17adr
 */
public class TransporteGasolina {
 
  //Base de datos
 
   public double regularPre = 877.12;
   public double diesPre = 734.20;
   public double plusPre = 635.13;
     
   //Choferes
   public String choferUno = "Roberto Morales";
   public String cedRob = "116984598";
   public String placaUno = "CP12897";
   
   public String choferDos = "Amelia Rodriguez";
   public String cedAme = "114326820";
   public String placaDos = "CP29031";
   
   public String choferTres = "Armando Gonzalez";
   public String cedArm = "559273174";
   public String placaTres = "CP57623";
   
   public int tipos;

 public void Bienvenida() {
     
  JOptionPane.showMessageDialog(null, "Bienvenid@ al modulo de transporte.");
     
 }//final de bienvenida 
 
 
 public void IngresoDatos() {
     
 JOptionPane.showMessageDialog(null, "Por favor, ingresar datos requeridos.", "" , JOptionPane.QUESTION_MESSAGE);

 }//final de IngresoDatos

 public void MenuGasolina() {

do {

tipos = Integer.parseInt(JOptionPane.showInputDialog(null, "Que tipo de gasolina desea comprar? 1.Regular-Super \n 2.Diesel \n 3.Plus 91 \n 0.Salir \n", JOptionPane.QUESTION_MESSAGE));

switch(tipos) {
     
 //Regular-Super 
   case 1:
        
 String litros1 = "Ingrese cantidad de litros a solicitar";
 int litrosRegular = Integer.parseInt(JOptionPane.showInputDialog(litros1));

    double tprecio1 = regularPre * litrosRegular;     
      System.out.println("Su pedido es Regular Super");
        System.out.println("Su chofer es: " +choferUno);   
          System.out.println("Cedula juridica de chofer: " +cedRob);
            System.out.println("Placa de camion: " +placaUno);
              System.out.println("Monto total: " +tprecio1);
                System.out.println("Cantidad de litros solicitados: " +litrosRegular);
                 System.out.println("------------------------------------------------------------------------");
                
                
break;

//Diesel
    case 2:
    
            
 String litros2 = "Ingrese cantidad de litros a solicitar";
 int litrosDiesel = Integer.parseInt(JOptionPane.showInputDialog(litros2));

    double tprecio2 = diesPre * litrosDiesel;    
     System.out.println("Su pedido es Diesel");
       System.out.println("Su chofer es: " +choferDos);   
         System.out.println("Cedula juridica de chofer: " +cedAme);
           System.out.println("Placa de camion: " +placaDos);
             System.out.println("Monto total: " +tprecio2);
               System.out.println("Cantidad de litros solicitados: " +litrosDiesel);
                  System.out.println("------------------------------------------------------------------------");
           
                
    break;
    
//Plus91
    case 3:

  String litros3 = "Ingrese cantidad de litros a solicitar";
  int litrosPlus = Integer.parseInt(JOptionPane.showInputDialog(litros3));

    double tprecio3 = diesPre * litrosPlus;     
      System.out.println("Su pedido es Plus91");
        System.out.println("Su chofer es: " +choferTres);   
          System.out.println("Cedula juridica de chofer: " +cedArm);
            System.out.println("Placa de camion: " +placaTres);
              System.out.println("Monto total: " +tprecio3);
                System.out.println("Cantidad de litros solicitados: " +litrosPlus);
                   System.out.println("------------------------------------------------------------------------");
   
                
    break;
    
   
       
       
}//final de switch    

} while (tipos != 0);


}//final de MenuGasolina

 
}//final de TransporteGasolina 