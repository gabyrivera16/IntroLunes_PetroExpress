/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package petroexpress.petroexpress;

import javax.swing.JOptionPane;
        
/**
 *
 * @author 17adr
 */
public class MetodoPago {
   
    
       //inicializacion de variables
        float desc=0;
        float sumprecio=0;
        String firma="";
        String[] metodoPago = new String[3];
                
   public void Bienvendida() {     
 
        //Imprimir: Bienvenido al módulo de métodos de pago
        JOptionPane.showMessageDialog(null, "Bienvendo al módulo de métodos de pago.");
        
   }//final bienvenida3
        
   public void Descuentos() {
       
   
        //Imprimir: Según el método de pago utilizado para la cotización, se le aplica un descuento sobre efectivo 10%, SInPE un 5% y Paypal un 2%
        JOptionPane.showMessageDialog(null,"Según el método de pago utilizado para la cotización, se le aplica un descuento: sobre efectivo 10%, SINPE un 5% y Paypal un 2%");
        
        //Imprimir elegir
        String pago = JOptionPane.showInputDialog(null,"Elija la opción escribiendo la letra correspondiente al método de pago (use mayúsculas): A. Efectivo B. SINPE C. Paypal D. Tarjeta de crédito o débito. ");

        //switch de metodo de pago
        switch(pago){
            case "A": 
                JOptionPane.showMessageDialog(null,"Al pagar en efectivo tiene un 10% de descuento.");
                desc=(float) (sumprecio*0.1);
                firma = JOptionPane.showInputDialog(null,"Firma digital: ");
                metodoPago[1] = "Descuento por cancelación en efectivo de 10%";
                metodoPago[2]="Firma digital: "+firma;
                System.out.println(metodoPago[1]);
                System.out.println(metodoPago[2]);
                break;
            case "B":
                JOptionPane.showMessageDialog(null,"Al pagar con SINPE tiene un 5% de descuento");
                desc=(float) (sumprecio*0.05);
                firma = JOptionPane.showInputDialog(null,"Firma digital: ");
                metodoPago[1] = "Descuento por cancelación con SINPE de 5%";
                metodoPago[2]="Firma digital: "+firma;
                System.out.println(metodoPago[1]);
                System.out.println(metodoPago[2]);
                break;
            case "C":
                JOptionPane.showMessageDialog(null,"Al pagar con Paypal tiene un 2% de descuento.");
                desc=(float) (sumprecio*0.02);
                firma = JOptionPane.showInputDialog(null,"Firma digital: ");
                metodoPago[1] = "Descuento por cancelación con Paypal de 2%";
                metodoPago[2]="Firma digital: "+firma;
                System.out.println(metodoPago[1]);
                System.out.println(metodoPago[2]);
                break;
            case "D":
                JOptionPane.showMessageDialog(null,"Se ha procesado su pago por medio de tarjeta.");
                firma = JOptionPane.showInputDialog(null,"Firma digital: ");
                metodoPago[1] = "Se procesó el pago por medio de tarjeta.";
                metodoPago[2]="Firma digital: "+firma;
                System.out.println(metodoPago[1]);
                System.out.println(metodoPago[2]);
                break;
            default:
                JOptionPane.showMessageDialog(null, "Usted no seleccionó una opción válida","Error",0);
        }//fin switch
        
       }//final de descuentos 
   
}//final de MetodoPago
