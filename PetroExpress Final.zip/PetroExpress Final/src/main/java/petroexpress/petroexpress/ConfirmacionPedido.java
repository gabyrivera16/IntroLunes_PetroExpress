/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package petroexpress.petroexpress;

import javax.swing.JOptionPane;

/**
 *
 * @author 17adr
 */
public class ConfirmacionPedido {

public void Bienvenida() {
    JOptionPane.showMessageDialog(null, "Bienvenid@ al modulo de Confirmacion de Pedido.");
}//final de bienvenida

public void Consultar(){    
    
 String mensaje = "Digite 1. Confirmar Pedido 2. Cancelar pedido";
   
    int respuesta = Integer.parseInt(JOptionPane.showInputDialog(mensaje));

    if(respuesta==1){
    JOptionPane.showMessageDialog(null, "Gracias. Su pedido ha sido confirmado.Ahora esta siendo procesado.");
 }//final de if
 
    else{
     JOptionPane.showMessageDialog(null, "Su pedido ha sido cancelado. Gracias por preferirnos.");
 
    }//final de else 
} //final de consultar   
    

}//final de ConfirmacionPedido
