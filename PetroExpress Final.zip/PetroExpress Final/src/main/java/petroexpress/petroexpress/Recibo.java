/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package petroexpress.petroexpress;
        
import javax.swing.JOptionPane;

/**
 *
 * @author 17adr
 */
public class Recibo {
      
   public void factelect(){
        
   int op = Integer.parseInt(JOptionPane.showInputDialog(null, "Si desea su factura impresa, digite 1. Y si desea que se enviada por email, digite 2.", "PetroExpress", JOptionPane.QUESTION_MESSAGE));
 
   if(op == 1) {
        
 String fecha1 = JOptionPane.showInputDialog(null, "Ingrese fecha de pedido: ");
 System.out.println("Fecha de pedido: "+fecha1);
     
 
 String destino1 = JOptionPane.showInputDialog(null, "Ingrese destino de producto: ");
 System.out.println("Destino de pedido: "+destino1);
     

 String compartimiento = JOptionPane.showInputDialog(null, "Ingrese numero de compartimiento en la cisterna(1 al 4).");
 System.out.println("Numero de compartimiento para producto: "+compartimiento);        
    
      String firma= JOptionPane.showInputDialog(null, "Ingrese su firma digital: ", "Atención",JOptionPane.INFORMATION_MESSAGE);
           System.out.println("Firmado por: "+firma);
             System.out.println("-------------------");
               System.out.println("Transacción finalizada, gracias por preferirnos. Vuelva Pronto!");
   
        }//fin if1
    
   if (op == 2) {
   
 String fecha1 = JOptionPane.showInputDialog(null, "Ingrese fecha de pedido: ");
 System.out.println("Firmado por: "+fecha1);
     
 
 String destino1 = JOptionPane.showInputDialog(null, "Ingrese destino de producto: ");
 System.out.println("Firmado por: "+destino1);
     

 String compartimiento = JOptionPane.showInputDialog(null, "Ingrese numero de compartimiento en la cisterna(1 al 4).");
 System.out.println("Firmado por: "+compartimiento);     
       
 String mail= JOptionPane.showInputDialog(null, "Ingrese su dirección de correo electrónico");
 JOptionPane.showMessageDialog(null, "La factura electrónica ha sido enviada a "+mail);
     String firma= JOptionPane.showInputDialog(null, "Ingrese su firma digital: ", "Atención",JOptionPane.INFORMATION_MESSAGE);
           System.out.println("Firmado por: "+firma);
             System.out.println("------------------------------------------------------------------------");
               System.out.println("Transacción finalizada, gracias por preferirnos. Vuelva Pronto!");
 
   
        
   }//final if2
        
    }//fin del metodo factelect
    

}//final de Recibo

