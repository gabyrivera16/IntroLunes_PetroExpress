/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package petroexpress.petroexpress;

import javax.swing.JOptionPane;
/**
 *
 * @author 17adr
 */
public class RecargaElectrica {
    
     //Scanner leer = new Scanner(System.in);
    int opcion = 0;
    int cantidad = 0;
    int vehiculos = 0;
    String lugar = "";
    
    double preConve = 230.3;
    double preSemi = 432.2;
    double preRap = 609.3;
    
    public void Bienvenida() {
        
     JOptionPane.showMessageDialog(null, "Bienvenid@ al modulo de Recarga Electrica.");
        
    }//final de bienvenida
  
    public void Menu(){
        do{
        opcion= Integer.parseInt(JOptionPane.showInputDialog(null, "1. Recarga Convencional, 2. Recarga Semi-Rápida y 3. Recarga Rápida o 0 para salir", "Seleccione su plan de recarga eléctrica", JOptionPane.QUESTION_MESSAGE));
        switch(opcion){
            case 1:
                cantidad = Integer.parseInt(JOptionPane.showInputDialog(null,"Digite la cantidad de la recarga:" ,"Cantidad de Recarga", JOptionPane.QUESTION_MESSAGE));
                vehiculos = Integer.parseInt(JOptionPane.showInputDialog(null,"Digite cuántos vehiculos desea recargar:" ,"Cantidad de Vehículos", JOptionPane.QUESTION_MESSAGE));
                lugar = JOptionPane.showInputDialog(null,"Digite dónde desea realizar su recarga:" ,"Lugar de recarga", JOptionPane.QUESTION_MESSAGE);
                System.out.println("Su pedido de Recarga Convencional.");
                System.out.println("Cantidad Recarga: " +cantidad);
                System.out.println("Vehículos: " +vehiculos); 
                System.out.println("Lugar de Recarga: " +lugar); 
                System.out.println("Precio total:" +cantidad * +preConve / +vehiculos);
                System.out.println("------------------------------------------------------------------------");
                break;
                
            case 2:
                cantidad = Integer.parseInt(JOptionPane.showInputDialog(null,"Digite la cantidad de la recarga:" , "Cantidad de Recarga", JOptionPane.QUESTION_MESSAGE));
                vehiculos = Integer.parseInt(JOptionPane.showInputDialog(null,"Digite cuántos vehiculos desea recargar:" ,"Cantidad de Vehículos", JOptionPane.QUESTION_MESSAGE));
                lugar = JOptionPane.showInputDialog(null,"Digite dónde desea realizar su recarga:" ,"Lugar de recarga", JOptionPane.QUESTION_MESSAGE);
                System.out.println("Su pedido de Recarga Convencional.");
                System.out.println("Cantidad Recarga: " +cantidad);
                System.out.println("Vehículos: " +vehiculos); 
                System.out.println("Lugar de Recarga: " +lugar); 
                System.out.println("Precio total:" +cantidad * +preConve / +vehiculos);
                System.out.println("------------------------------------------------------------------------");
                break;
                
            case 3:
                cantidad = Integer.parseInt(JOptionPane.showInputDialog(null,"Digite la cantidad de la recarga:" ,"Cantidad de Recarga", JOptionPane.QUESTION_MESSAGE));
                vehiculos = Integer.parseInt(JOptionPane.showInputDialog(null,"Digite cuántos vehiculos desea recargar:" ,"Cantidad de Vehículos", JOptionPane.QUESTION_MESSAGE));
                lugar = JOptionPane.showInputDialog(null,"Digite dónde desea realizar su recarga:" ,"Lugar de recarga", JOptionPane.QUESTION_MESSAGE);
                System.out.println("Su pedido de Recarga Convencional.");
                System.out.println("Cantidad Recarga: " +cantidad);
                System.out.println("Vehículos: " +vehiculos); 
                System.out.println("Lugar de Recarga: " +lugar); 
                System.out.println("Precio total:" +cantidad * +preConve / +vehiculos);
                System.out.println("------------------------------------------------------------------------");
                break;
                
        }//fin switch
        }while(opcion!=0);           
    
    }//final de menu
    
}//final de RecargaElectronica
